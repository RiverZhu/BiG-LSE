% For reproducibility
clc
clear
close all
rng(3);


% Parameters
N = 2^8;
K = 10;
% K = round(N/10);
index = (1:N)';
snr = 20;	% dB

% Select frequencies by rejection sampling
% (avoid closely located frequencies)
% while true
% 	freqs = sort(rand(K,1));
% 	if all(diff(freqs)>2/N) ...
% 			&& (freqs(1)-freqs(end)+1) > 2/N
% 		break;
% 	end
% end
freqs = sort(rand(K,1));

% Generate signal
alpha = randn(K, 2) * [1;1j];
alpha = alpha./abs(alpha);	% Normalize to magnitude 1
x = exp(-1j*2*pi*index*freqs') * alpha;
noiseVar = mean(abs(x).^2) / 10^(snr/10);
y = x + sqrt(noiseVar/2) * randn(N, 2) * [1;1j];

% Run algorithm
% superfast-LSE
tic
out1 = superfast_lse(y, index, N, 'verbose',false, 'plot',false);
time_SFLSE = toc
NMSE_SFLSE = 10*log10(sum(abs(out1.h-x).^2)./sum(abs(x).^2))

% BiG-EPLSE
init.N = N; init.L = 4*N; init.iter_max = 20;
out2 = fun_BiGEPLSE(y, init);
z_his = out2.z_his;
time_EPbase = out2.time;
NMSE_EPbase = 10*log10(sum(abs(z_his-x*ones(1,init.iter_max)).^2)./norm(x)^2);

figure(1)
stem(abs(out2.xhat))

freq_est_EPLSE = out2.dhat([61;99])+out2.theta0([61;99]);
fre_real = 2*pi*(1-freqs')
SFLSE_est = 2*pi*(1-out1.tau)
% A_EPLSE = exp(1j*(index-1)*freq_est_EPLSE');
% xhat_EPLSE = A_EPLSE\y;
% zhat_EPLSE = A_EPLSE*xhat_EPLSE;
% NMSE_EPLSE = 10*log10(sum(abs(zhat_EPLSE-x).^2)./sum(abs(x).^2));


% Print result
% fprintf('True freqs,  Estimated freqs, Difference\n');
% [freqs, out1.tau, abs(freqs-out1.tau)]
